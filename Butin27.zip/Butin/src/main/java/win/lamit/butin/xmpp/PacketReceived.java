package win.lamit.butin.xmpp;

public abstract interface PacketReceived {

}
