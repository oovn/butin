package win.lamit.butin.utils;

public class FileWriterException extends Exception {
}
