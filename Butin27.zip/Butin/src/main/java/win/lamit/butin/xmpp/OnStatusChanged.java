package win.lamit.butin.xmpp;

import win.lamit.butin.entities.Account;

public interface OnStatusChanged {
	public void onStatusChanged(Account account);
}
