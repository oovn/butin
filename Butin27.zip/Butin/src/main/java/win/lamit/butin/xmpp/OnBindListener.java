package win.lamit.butin.xmpp;

import win.lamit.butin.entities.Account;

public interface OnBindListener {
	public void onBind(Account account);
}
