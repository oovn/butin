package win.lamit.butin.crypto.axolotl;

public class NoSessionsCreatedException extends Throwable{
}
