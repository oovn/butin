package win.lamit.butin.persistance;

public interface OnPhoneContactsMerged {
	public void phoneContactsMerged();
}
