package win.lamit.butin.xmpp.jingle;

public interface OnTransportConnected {
	public void failed();

	public void established();
}
