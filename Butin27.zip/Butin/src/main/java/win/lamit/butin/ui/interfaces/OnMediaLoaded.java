package win.lamit.butin.ui.interfaces;

import java.util.List;

import win.lamit.butin.ui.util.Attachment;

public interface OnMediaLoaded {

    void onMediaLoaded(List<Attachment> attachments);
}
