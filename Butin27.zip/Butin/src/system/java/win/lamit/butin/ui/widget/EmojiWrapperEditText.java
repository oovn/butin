package win.lamit.butin.ui.widget;

import android.content.Context;
import android.support.v7.widget.AppCompatEditText;
import android.util.AttributeSet;

public class EmojiWrapperEditText extends AppCompatEditText {

    public EmojiWrapperEditText(Context context) {
        super(context);
    }

    public EmojiWrapperEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}