package win.lamit.butin.ui.service;

import android.content.Context;

public class EmojiService {

    public EmojiService(Context context) {
        //nop
    }

    public void init() {
        //nop
    }
}