package win.lamit.butin.ui.widget;

import android.content.Context;
import android.support.text.emoji.widget.EmojiAppCompatEditText;
import android.util.AttributeSet;

public class EmojiWrapperEditText extends EmojiAppCompatEditText {

    public EmojiWrapperEditText(Context context) {
        super(context);
    }

    public EmojiWrapperEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

}